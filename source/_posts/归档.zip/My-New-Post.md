---
title: 这是我的第一篇Hexo博客
date: 2016-10-21 10:59:40
categories: 个人随写
tags:
---
> 一天不独处，我就会变得虚弱。我不以孤独为荣，但我以此为生
> 布考斯基 


<br/>
 {% img [full-image] /images/20140111004002.jpg %}
 这是我的第一篇博客，我现在正在熟悉Hexo,所使用的主题是NexT,我觉得这个主题简洁大方，而且里边的缓动效果特别舒服。
 
 我以后会不定时的在这上边更新一些博客，什么类型的都有，写给自己看，写给多年后的自己看。
 
 加油， 每天进步一点，不断努力，终会取得不错的成绩！
 <!-- more -->
 


{% blockquote  %}

{% endblockquote %}



<img src="/images/bg_web.jpg" class="full-image" />