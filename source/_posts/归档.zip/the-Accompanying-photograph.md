---
title: 周末随拍（2016.11.13）
date: 2016-11-16 15:42:07
categories: 个人随写
tags: Photo
---

{% img [full-image]  /images/20161113/8.jpg %}

<!-- more -->

{% img [full-image]  /images/20161113/0.jpg %}

 <center>兴庆公园</center>
 
{% img [full-image]  /images/20161113/2.jpg %}

 <center>兴庆公园</center>
 
{% img [full-image]  /images/20161113/3.jpg %}

 <center>兴庆公园</center>
 
{% img [full-image]  /images/20161113/4.jpg %}

 <center>兴庆公园</center>
 
{% img [full-image]  /images/20161113/5.jpg %}

 <center>大雁塔北广场音乐喷泉</center>
 
{% img [full-image]  /images/20161113/7.jpg %}

<center>大雁塔北广场音乐喷泉</center>

{% img [full-image]  /images/20161113/8.jpg %}

<center>大雁塔北广场音乐喷泉</center>

{% img [full-image]  /images/20161113/10.jpg %}

<center>大雁塔北广场音乐喷泉</center>

{% img [full-image]  /images/20161113/12.jpg %}

<center>大雁塔</center>

{% img [full-image]  /images/20161113/13.jpg %}

<center>小寨</center>



<center>#拍摄来自魅蓝E#</center>
